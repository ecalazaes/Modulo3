export interface Empresa{
  empresa_id?: number;
  empresa_nome: string;
  empresa_cnpj: string;
}
